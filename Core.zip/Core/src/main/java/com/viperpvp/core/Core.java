package com.viperpvp.core;

import com.viperpvp.core.achievement.Achievement;
import com.viperpvp.core.achievement.AchievementHandler;
import com.viperpvp.core.achievement.FirstJoin;
import com.viperpvp.core.player.Connector;
import com.viperpvp.core.player.PlayerManager;
import com.viperpvp.core.sql.SQLManager;
import com.viperpvp.core.statistic.Statistic;
import com.viperpvp.core.statistic.StatisticHandler;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import rx.Observable;
import tech.rayline.core.library.IgnoreLibraries;
import tech.rayline.core.library.MavenLibraries;
import tech.rayline.core.library.MavenLibrary;
import tech.rayline.core.plugin.RedemptivePlugin;
import tech.rayline.core.rx.EventStreamer;

/**
 * Created by Matt on 09/08/2016.
 */
@IgnoreLibraries
public class Core extends RedemptivePlugin {

    private static Core instance;
    private AchievementHandler achievementHandler;
    private PlayerManager playerManager;
    private StatisticHandler statisticHandler;

    private SQLManager sqlManager;

    @Override
    protected void onModuleEnable() throws Exception {
        instance = this;
        sqlManager = new SQLManager("localhost", "3306", "network", "minecraft", "test");
        playerManager = new PlayerManager(this);

        /**
         * Instantiate Connector
         */
        new Connector(this);

        achievementHandler = new AchievementHandler();
        statisticHandler = new StatisticHandler();
    }

    @Override
    protected void onModuleDisable() throws Exception {
        instance = null;
    }

    public static Core getInstance() {
        return instance;
    }

    public AchievementHandler getAchievementHandler() {
        return achievementHandler;
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }

    public SQLManager getSqlManager() {
        return sqlManager;
    }

    public StatisticHandler getStatisticHandler() {
        return statisticHandler;
    }
}
