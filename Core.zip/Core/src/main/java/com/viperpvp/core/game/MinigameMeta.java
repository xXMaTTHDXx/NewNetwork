package com.viperpvp.core.game;

/**
 * Created by Matt on 23/08/2016.
 */
public @interface MinigameMeta {
    String name();
    String description();
    String[] authors();

    MinigameType type();
}
