package com.viperpvp.core.game;

import org.bukkit.event.Event;

/**
 * Created by Matt on 23/08/2016.
 */
public interface GameListener<T extends Event> {

    void onEvent(T event);
}
