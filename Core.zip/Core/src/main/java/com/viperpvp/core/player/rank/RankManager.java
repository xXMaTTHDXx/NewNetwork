package com.viperpvp.core.player.rank;

/**
 * Created by Matt on 10/08/2016.
 */
public class RankManager {
}
