package com.viperpvp.core.achievement;

import com.viperpvp.core.Core;
import com.viperpvp.core.player.CPlayer;
import com.viperpvp.core.player.PlayerManager;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Matt on 10/08/2016.
 */
public class AchievementHandler {

    private List<Achievement> allAchievements = new ArrayList<>();

    public AchievementHandler() {
        init();
    }

    public Achievement getFromString(String name) {
        for (Achievement a : allAchievements) {
            if (a.getName().equalsIgnoreCase(name)) {
                return a;
            }
        }
        return null;
    }

    public void init() {
        allAchievements.clear();
        allAchievements.add(new FirstJoin());
        allAchievements.add(new PunchTheAuthority());
    }

    public boolean hasAchievement(Player player, Achievement achievement) {
        return Core.getInstance().getPlayerManager().getPlayer(player).getMeta().getAchievements().contains(achievement);
    }

    public void addAchievement(Achievement achievement) {
        if (allAchievements.contains(achievement)) {
            return;
        }

        allAchievements.add(achievement);
    }
}
