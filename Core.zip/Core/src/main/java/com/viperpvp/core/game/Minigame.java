package com.viperpvp.core.game;

import com.viperpvp.core.game.arena.AbstractArena;
import com.viperpvp.core.game.team.Team;
import com.viperpvp.core.player.CPlayer;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Matt on 23/08/2016.
 */
public abstract class Minigame {

    private String name;
    private List<GameListener> events;
    private List<Team> teams;

    private AbstractArena currentArena;
    private List<CPlayer> allPlayers;

    public Minigame(String name, AbstractArena currentArena) {
        this.name = name;
        this.currentArena = currentArena;
        this.allPlayers = new ArrayList<>();
        this.teams = new ArrayList<>();
    }

    public final List<CPlayer> collectFromTeams() {
        List<CPlayer> all = new ArrayList<>();
        for (Team t : teams) {
            all.addAll(t.getMembers());
        }
        return all;
    }

    public abstract void onRegister();

    public abstract void onStart();

    public abstract void onFinish(Winnable winnable);
}
